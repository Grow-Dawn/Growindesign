<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Contact Us</title>
    <!--Doing this for a friend-->
    <link type="text/css" media="screen" rel="stylesheet" href="/Universal%20WD/UWDstyle.css"/>
    <meta name="viewport" content="width=device-width,initial-scale=1.0,maximum-scale=1.0">
    
    <script type="text/javascript">
    
    </script>
</head>


<body>
    <img class="logo" src="UWD%20pictures/UWD2.png" alt="Smiley Face">
    <h1>Universal Well Drilling Services</h1>
    <h1>"Honest Water at an Honest Price"</h1>
    <h1>Contact Us</h1>
    <?php include $_SERVER['DOCUMENT_ROOT'].'/modules/UWD footer.php'; ?>
    <br> <p class="right"><strong>
        Universal Well Drilling<br>
Serving The Northwest<br>
<br>
(208)290-1069<br>
(406)293-1151<br><br>
Licensed in Idaho and Montana </strong></p>
<a class="rightpic" href="UWD%20pictures/ResizedImage_1403879642055b.jpg" title="enlarge">
        <img class="right2" src="UWD%20pictures/ResizedImage_1403879642055b.jpg" alt="Smiley Face"></a> 
        
    <p> <strong>We'd Like To Hear From You</strong> <br>
  	Feel free to contact us with any 	 
  	projects or questions you have.
        Free estimates. <br><br>
        Serving The Northwest <br><br>
        <strong>
        Universal Well Drilling<br>
        208-290-1069<br>
        406-293-1151<br>
        90 Basin Lane <br>	 
  	Bonners Ferry Id, 83845<br><br>
        Scott Hittle, Owner<br>
        Phone . . . 1-208-290-1069 <br>	 
  	Fax. . . . . .  208-267-6657 	 <br>
  	E-mail . . . universaldrilling@live.com
                <br><br></strong>
        Contact<br>
        Scott Hittle . . . Owner/Operator  (208)290-1069<br>
        Jamon Ensz . . . Pump Installation (208)610-8410<br>
        Angela Hittle . . . Office Manager  (208)946-3017<br>
        Austin Hittle . . . Driller Help<br>
        Rory Kramer . . . Driller Help<br><br>
        Licensed in Idaho and Montana <br><br>
        Please feel free to call or email us at any time.  We are here to help you.  
        
        <br><br> If you have any questions, fill out the information below.  Please fill in all the blanks.<br> </p>
   
   <form action="/assessments/contact/index3.php" id="contactform" method="post">
        <fieldset>
            <label for="name">Name:</label> <input id="name" name="name"
            required="" size="25" type="text" value="<?php echo $name; ?>"><br>
            <label for="email">Email Address:</label> <input id="email" name=
            "email" size="40" type="email"><br>
            <label for="subject">Subject:</label> <input id="subject" name=
            "subject" size="40" type="text"><br>
            <label for="message">Message:</label><br>
            <textarea cols="60" id="message" name="message" rows="10">
</textarea><br>
            Answer the following CAPTCHA question in the box below.<br>
            <label for="captcha">What color is a red apple?</label> <input id=
            "captcha" name="captcha" size="5" type="text"><br>
            <label for="action">&nbsp;</label><br>
            <input id="action" name="action" type="submit" value="Send"><br>
        </fieldset>
    </form>

        <script type="text/javascript">
   
    </script>
    
   <br><br><br>
     
&#169; GrowinDesign
   
</body>
</html>