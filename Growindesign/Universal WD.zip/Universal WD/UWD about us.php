<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Universal About Us</title>
    <!--Doing this for a friend-->
    <link type="text/css" media="screen" rel="stylesheet" href="/Universal%20WD/UWDstyle.css"/>
    <meta name="viewport" content="width=device-width,initial-scale=1.0,maximum-scale=1.0">
    
</head>

 <body>
    <img class="logo" src="UWD%20pictures/UWD2.png" alt="Smiley Face">
    <h1>Universal Well Drilling Services</h1>
    <h1>"Honest Water at an Honest Price"</h1>    
    <h1>About Us</h1>  
        <?php include $_SERVER['DOCUMENT_ROOT'].'/modules/UWD footer.php'; ?> 
        <br> <p class="right"><strong>
        Universal Well Drilling<br>
Serving The Northwest<br>
<br>
(208)290-1069<br>
(406)293-1151<br><br>
Licensed in Idaho and Montana </strong></p>
<a class="rightpic" href="UWD%20pictures/IMAG0074b.jpg" title="enlarge">
        <img class="right2" src="UWD%20pictures/IMAG0074b.jpg" alt="Smiley Face"></a>
        <a class="rightpic" href="UWD%20pictures/IMAG0042.png" title="enlarge">
        <img class="right2" src="UWD%20pictures/IMAG0042.png" alt="Smiley Face"></a>
        
    <p><strong> Our Company</strong><br>
Our small company allows us the privilege of being able to provide you with unbeatable 
service. Though small, every job is of great importance to us. We are here to offer 
whatever service necessary. Our crew members are certified and well experienced. We 
make every effort to continue our education and training as the industry changes and grows.
<br><br>
Our Foremost drill rig is at the top of technological advancement and designed to handle 
the most difficult drilling situations. We maintain our equipment. 
We drill the average well in 1-2 days time.  
<br><br>
<strong>Our Service</strong><br>
Our purpose is to provide the best service possible and make your well drilling project an 
enjoyable experience! Our company , Universal Well Drilling, is family owned and operated. 
Our customers ask us frequently if they should be on site when we are drilling the well. 
This is entirely your decision. We would like to have you there if possible. If you are not 
able to be on site, we will maintain contact with you and give progress reports at any time. 
The quality of service will be the same whether you are there or not.  We will do our best to 
schedule your drilling and/or pump installation project when it works 
best for you. Due to the many variables in our line of work, it can be a challenge to predict our 
schedule. Please schedule us at your convenience.
<br><br>
<strong>To Finish The Job</strong><br>
When we are done working we will clean up thoroughly and to your satisfaction. We will go 
over the job with you and make sure you are happy with our work. We want to treat you with 
the respect you deserve while working on your property and your project. Thank-you again for 
your consideration . We look forward to serving you! 
   <br> </p>  
    
   
  
   
 &#169; GrowinDesign      

</body>
</html>