<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Universal Home</title>
    <!--Doing this for a friend-->
    <link type="text/css" media="screen" rel="stylesheet" href="/Universal%20WD/UWDstyle.css"/>
    <meta name="viewport" content="width=device-width,initial-scale=1.0,maximum-scale=1.0">
    
</head>

<body>
    <img class="logo" src="UWD%20pictures/UWD2.png" alt="Smiley Face">
    <h1>Universal Well Drilling Services</h1>
    <h1>"Honest Water at an Honest Price"</h1>
    <h1>Home Page</h1>
    <?php include $_SERVER['DOCUMENT_ROOT'].'/modules/UWD footer.php'; ?>
    <br> <p class="right"><strong>
        Universal Well Drilling<br>
Serving The Northwest<br>
<br>
(208)290-1069<br>
(406)293-1151
<br><br>
Licensed in Idaho and Montana </strong></p>
<a class="rightpic" href="UWD%20pictures/ResizedImage_1403879642450.jpg" title="enlarge">
        <img class="right2" src="UWD%20pictures/ResizedImage_1403879642450.jpg" alt="Smiley Face"></a>

 <p class="right"><strong>
        We offer everything you need to finish the job.</strong><br>
We not only drill the well but install the pumps. We are the complete package.</p>


<p><br><strong>"Honest Water at an Honest Price" </strong><br><br>

There's nothing more important than safe affordable drinking water for your home. 
Ground water is pure & clean. Water wells drilled into the aquifers safely supply more than 
half of America's drinking water every day. It is filtered through the soil and then stored 
in a deep, cool, natural environment.  <br>
Universal Well Drilling has been operating since 2006. Scott Hittle is the owner/operator. 
He is licensed in Idaho & Montana. Scott goes out and does on site evaluations and estimates for free, 
7 days a week. Customer service is our #1 priority. Family-owned and operated, 
Universal Well Drilling offers quality workmanship, 
modern machinery, and advanced technology.  We have invested money into equipment 
that enables us to drill deep through tough terrain - 
terrain that would stop many other drills.
 <br><br>
Water is a necessity for life, and in remote areas of the Northwest, a well is often a 
necessary step in creating a home. Call Universal Well Drilling and experience "Honest Water at an Honest Price!"   
Bonners Ferry, Sandpoint, Clarkfork, Libby, Troy, Eureka.<br>
    </p>
    
      
       
    <div id="bottom">
        <a href="http://www.igwa.info/" title="IGWA"><img src="UWD%20pictures/igwa.jpg" alt="Smiley Face"></a>
        <a href="http://www.ngwa.org/Pages/default.aspx" title="NGWA"><img src="UWD%20pictures/ngwa.jpg" alt="Smiley Face"></a>
        <a href="http://www.idwr.idaho.gov/" title="Idaho Water"><img src="UWD%20pictures/seal5.gif" alt="Smiley Face"></a>
        <a class="bottom" href="UWD%20pictures/watersystems2.jpg" title="enlarge">
        <img class="bottom" src="UWD%20pictures/watersystems2.jpg" alt="Smiley Face"></a><br>
    </div>   
    
    &#169; GrowinDesign
 
</body>
</html>