<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Universal Services</title>
    <!--Doing this for a friend-->
    <link type="text/css" media="screen" rel="stylesheet" href="/Universal%20WD/UWDstyle.css"/>
    <meta name="viewport" content="width=device-width,initial-scale=1.0,maximum-scale=1.0">
    
</head>

 <body>
    <img class="logo" src="UWD%20pictures/UWD2.png" alt="Smiley Face">
    <h1>Universal Well Drilling Services</h1>
    <h1>"Honest Water at an Honest Price"</h1>    
    <h1>Services</h1>  
        <?php include $_SERVER['DOCUMENT_ROOT'].'/modules/UWD footer.php'; ?> 
        <br> <p class="right"><strong>
        Universal Well Drilling<br>
Serving The Northwest<br>
<br>
(208)290-1069<br>
(406)293-1151<br><br>
Licensed in Idaho and Montana </strong></p>
<a class="rightpic" href="UWD%20pictures/ResizedImage_1403877832807.jpg" title="enlarge">
        <img class="right2" src="UWD%20pictures/ResizedImage_1403877832807.jpg" alt="Smiley Face"></a> 
<a class="rightpic" href="UWD%20pictures/ResizedImage_1403877830718.jpg" title="enlarge">
        <img class="right2" src="UWD%20pictures/ResizedImage_1403877830718.jpg" alt="Smiley Face"></a>       
    <p><strong> Full Service Water Company - Serving The North Idaho and Montana</strong><br>
Whether for residential or commercial projects, or just some professional advice, 
we are here to help. Our crew members are certified and well experienced. We make 
every effort to continue our education and training as the industry changes and grows.
<br><br></p>
<ul>
        <li>Residential & Irrigation Wells</li>
        <li>Commercial & Public Systems</li>
        <li>Pump Systems & Supplies In Stock</li>
        <li>Water Treatment & Testing</li>
        <li>Water Softeners In Stock</li>
        <li>24 Hour Pump Service & Repair</li>
        <li>Well Inspection & Testing</li>
    </ul>
<p>
Our purpose is to provide the best service possible and make your well drilling project 
or water system project an enjoyable experience!  We will do our best to schedule your 
drilling or pump installation project when it works best for you.
</p><br><br>
 <div id="bottom">
     <a href="http://www.water-right.com/" title="IGWA"><img src="UWD%20pictures/waterright.jpg" alt="Smiley Face"></a>
     <a href="http://www.dekorraproducts.com/" title="NGWA"><img src="UWD%20pictures/dekorra.jpg" alt="Smiley Face"></a>
 </div>  
    
&#169; GrowinDesign   	

</body>
</html>